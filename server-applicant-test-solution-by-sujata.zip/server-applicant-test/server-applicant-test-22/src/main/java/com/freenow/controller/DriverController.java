/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.controller;

import com.freenow.controller.mapper.DriverMapper;
import com.freenow.criteria.driver.DriverCriteria;
import com.freenow.criteria.driver.DriverCriteriaBuilder;
import com.freenow.datatransferobject.DriverDTO;
import com.freenow.datatransferobject.SearchDTO;
import com.freenow.domainobject.DriverDO;
import com.freenow.domainvalue.OnlineStatus;
import com.freenow.exception.CarAlreadyInUseException;
import com.freenow.exception.ConstraintsViolationException;
import com.freenow.exception.EntityNotFoundException;
import com.freenow.exception.InvalidCriteriaException;
import com.freenow.service.driver.DriverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

/**
 * All operations with a driver will be routed by this controller.
 * <p/>
 */
@RestController
@RequestMapping("v1/drivers")
@PreAuthorize("hasRole('ADMIN') or hasRole('USER')")
public class DriverController
{

    private final DriverService driverService;


    @Autowired
    public DriverController(final DriverService driverService)
    {
        this.driverService = driverService;
    }


    @GetMapping("/{driverId}")
    public DriverDTO getDriver(@PathVariable long driverId) throws EntityNotFoundException
    {
        return DriverMapper.makeDriverDTO(driverService.find(driverId));
    }


    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public DriverDTO createDriver(@Valid @RequestBody DriverDTO driverDTO) throws ConstraintsViolationException
    {
        DriverDO driverDO = DriverMapper.makeDriverDO(driverDTO);
        return DriverMapper.makeDriverDTO(driverService.create(driverDO));
    }


    @DeleteMapping("/{driverId}")
    public void deleteDriver(@PathVariable long driverId) throws EntityNotFoundException
    {
        driverService.delete(driverId);
    }


    @PutMapping("/{driverId}")
    public void updateLocation(
        @PathVariable long driverId, @RequestParam double longitude, @RequestParam double latitude)
        throws EntityNotFoundException
    {
        driverService.updateLocation(driverId, longitude, latitude);
    }


    @GetMapping
    public List<DriverDTO> findDrivers(@RequestParam OnlineStatus onlineStatus)
    {
        return DriverMapper.makeDriverDTOList(driverService.find(onlineStatus));
    }


    /**
     * To get a list of drivers with specific characteristics
     * @param searchCriteria criteria to filter
     * @return list of drivers matched with given criteria
     * @exception InvalidCriteriaException in case of invalid criteria
     * */
    @PostMapping("/search")
    public List<DriverDTO> searchDrivers(@Valid @RequestBody SearchDTO searchCriteria) throws InvalidCriteriaException {
        DriverCriteria criteria = DriverCriteriaBuilder.build(searchCriteria);
        return DriverMapper.makeDriverDTOList(driverService.findByCriteria(criteria));
    }


    @PutMapping
    public DriverDO selectCar(@RequestParam Long carId, @RequestParam Long driverId) throws EntityNotFoundException, ConstraintsViolationException, CarAlreadyInUseException {
        return driverService.assignCarToDriver(carId, driverId);
    }

    @PutMapping("/unassignDriver{/driverId}")
    public DriverDO deSelectCar(@RequestParam Long driverId) throws EntityNotFoundException {
        return driverService.unassignCarFromDriver(driverId);
    }
}
