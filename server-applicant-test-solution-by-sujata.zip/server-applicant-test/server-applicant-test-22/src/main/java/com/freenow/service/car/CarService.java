/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.service.car;

import com.freenow.criteria.car.CarCriteria;
import com.freenow.domainobject.CarDO;
import com.freenow.exception.ConstraintsViolationException;
import com.freenow.exception.EntityNotFoundException;

import java.util.List;

/**
 * Service endpoint for all operations related to Car
 * @author Sujata
 * @since 22-NOV-2019
 * @version 1.0
 * */
public interface CarService {
    CarDO get(Long carId) throws EntityNotFoundException;

    CarDO create(CarDO carDO) throws ConstraintsViolationException;

    void delete(Long carId) throws EntityNotFoundException;

    CarDO updateLocation(long carId, double longitude, double latitude) throws EntityNotFoundException;

    Iterable<CarDO> getAll();

    List<CarDO> getAvailableCars();

    List<CarDO> findByCriteria(CarCriteria criteria);
}
