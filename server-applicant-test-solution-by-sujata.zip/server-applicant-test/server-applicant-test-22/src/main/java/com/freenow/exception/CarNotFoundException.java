/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "The car is not found.")
public class CarNotFoundException extends Exception
{

    /**
     * 
     */
    private static final long serialVersionUID = -3427288148948321775L;


    public CarNotFoundException()
    {
        super();
    }


    public CarNotFoundException(String message)
    {
        super(message);
    }
}
