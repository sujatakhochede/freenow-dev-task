/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.criteria.driver;

import com.freenow.domainobject.DriverDO;

import java.util.List;

public interface DriverCriteria {
    List<DriverDO> meetCriteria(final List<DriverDO> drivers);
}
