/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.datatransferobject;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.freenow.domainvalue.AttributeType;
import com.freenow.domainvalue.CriteriaType;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SearchDTO {
    private AttributeType attribute;
    private String value;
    private CriteriaType criteriaType;
    private SearchDTO criteria;
    private SearchDTO otherCriteria;

    public SearchDTO() {}

    public SearchDTO(AttributeType attribute, String value) {
        this.attribute = attribute;
        this.value = value;
    }

    public SearchDTO(AttributeType attribute, String value,
                     CriteriaType criteriaType,
                     SearchDTO criteria, SearchDTO otherCriteria) {
        this.attribute = attribute;
        this.value = value;
        this.criteriaType = criteriaType;
        this.criteria = criteria;
        this.otherCriteria = otherCriteria;
    }

    public AttributeType getAttribute() {
        return attribute;
    }

    public String getValue() {
        return value;
    }

    public CriteriaType getCriteriaType() {
        return criteriaType;
    }

    public SearchDTO getCriteria() {
        return criteria;
    }

    public SearchDTO getOtherCriteria() {
        return otherCriteria;
    }
}
