/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.criteria.car;

import com.freenow.datatransferobject.SearchDTO;
import com.freenow.domainobject.ManufacturerDO;
import com.freenow.domainvalue.AttributeType;
import com.freenow.domainvalue.CriteriaType;
import com.freenow.domainvalue.EngineType;
import com.freenow.exception.InvalidCriteriaException;
import org.springframework.util.StringUtils;

public class CarCriteriaBuilder {
    static CarCriteria rootCriteria = null;

    public static CarCriteria build(SearchDTO node) throws InvalidCriteriaException {


        if (node == null) {
            return null;
        }

        if (CriteriaType.AND == node.getCriteriaType()) {
            CarCriteria criteria1 = buildCriteria(node.getAttribute(), node.getValue());
            if (node.getOtherCriteria() != null) {
                CarCriteria criteria2 = build(node.getOtherCriteria());
                rootCriteria = new AndCarCriteria(criteria1, criteria2);
            }

        } else if (CriteriaType.OR == node.getCriteriaType()) {
            CarCriteria criteria1 = buildCriteria(node.getAttribute(), node.getValue());
            if (node.getOtherCriteria() != null) {
                CarCriteria criteria2 = build(node.getOtherCriteria());
                rootCriteria = new OrCarCriteria(criteria1, criteria2);
            }

        } else {
            AttributeType attribute = node.getAttribute();
            String value = node.getValue();
            rootCriteria = buildCriteria(attribute, value);
        }

        return rootCriteria;
    }

    private static CarCriteria buildCriteria(AttributeType attribute, String value) throws InvalidCriteriaException {
        CarCriteria criteria = null;
        switch (attribute) {
            case ENGINE_TYPE:
                criteria = new CarEngineCarCriteria(getEngineType(value));
                break;

            case MANUFACTURER:
                criteria = new CarManufacturerCarCriteria(getManufacturer(value));
                break;

            case RATING:
                criteria = new CarRatingCarCriteria(getRating(value));
                break;

            case LICENSE_PLATE:
                criteria = new LicensePlateCarCriteria(getLicensePlate(value));
                break;

            default:
                break;
        }

        return criteria;
    }

    private static String getLicensePlate(String value) throws InvalidCriteriaException {
        if (StringUtils.isEmpty(value)) {
            throw new InvalidCriteriaException("License Plate can not be empty");
        }
        return value;
    }

    private static EngineType getEngineType(String value) throws InvalidCriteriaException {
        EngineType engine = null;
        if (value != null) {
            try {
                engine = EngineType.valueOf(value);
            } catch (IllegalArgumentException e) {
                throw new InvalidCriteriaException("Invalid engine type");
            }

        }
        return engine;
    }

    private static Float getRating(String value) throws InvalidCriteriaException {
        Float rating;
        try {
            rating = Float.valueOf(value);
        } catch (IllegalArgumentException e) {
            throw new InvalidCriteriaException("Invalid rating");
        }
        return rating;
    }


    private static ManufacturerDO getManufacturer(String value) throws InvalidCriteriaException {
        ManufacturerDO manufacturer = new ManufacturerDO(value);

        return manufacturer;
    }
}
