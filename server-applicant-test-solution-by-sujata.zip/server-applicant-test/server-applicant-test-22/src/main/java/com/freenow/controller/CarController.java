/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.controller;

import com.freenow.controller.mapper.CarMapper;
import com.freenow.criteria.car.CarCriteria;
import com.freenow.criteria.car.CarCriteriaBuilder;
import com.freenow.datatransferobject.CarDTO;
import com.freenow.datatransferobject.SearchDTO;
import com.freenow.domainobject.CarDO;
import com.freenow.exception.ConstraintsViolationException;
import com.freenow.exception.EntityNotFoundException;
import com.freenow.exception.InvalidCriteriaException;
import com.freenow.service.car.CarService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Collection;
import java.util.List;


/**
 * Controller for all car operations
 * @author Sujata
 * @since 22-NOV-2019
 * @version 1.0
 * */
@RestController
@RequestMapping("v1/cars")
public class CarController {
    private final CarService carService;

    public CarController(final CarService carService) {
        this.carService = carService;
    }

    @GetMapping("/{carId}")
    public CarDTO getCar(@Valid @PathVariable long carId) throws EntityNotFoundException {
        return CarMapper.makeCarDTO(carService.get(carId));
    }

    @GetMapping("/allCars")
    public List<CarDTO> getAllCars(){
        return CarMapper.makeCarDTOList((Collection<CarDO>) carService.getAll());
    }

    @GetMapping
    public List<CarDTO> getAvailableCars(){
        return CarMapper.makeCarDTOList(carService.getAvailableCars());
    }


    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CarDTO createCar(@Valid @RequestBody CarDTO carDTO) throws ConstraintsViolationException {
        CarDO carDO = CarMapper.makeCarDO(carDTO);
        return CarMapper.makeCarDTO(carService.create(carDO));
    }

    @DeleteMapping("/{carId}")
    public void deleteCar(@Valid @RequestParam long carId) throws EntityNotFoundException {
        carService.delete(carId);
    }

    @PutMapping("/{carId}")
    public CarDTO updateLocation(
            @Valid @RequestParam long carId, @RequestParam double longitude, @RequestParam double latitude)
            throws EntityNotFoundException {
        return CarMapper.makeCarDTO(carService.updateLocation(carId, longitude, latitude));
    }

    /**
     * To get a list of cars with specific characteristics
     * @param filterCriteria criteria to filter
     * @return list of cars matched with given criteria
     * @exception InvalidCriteriaException in case of invalid criteria
     * */
    @PostMapping("/filter")
    public List<CarDTO> filterCars(@Valid @RequestBody SearchDTO filterCriteria) throws InvalidCriteriaException {
        CarCriteria criteria = CarCriteriaBuilder.build(filterCriteria);
        return CarMapper.makeCarDTOList(carService.findByCriteria(criteria));
    }

}
