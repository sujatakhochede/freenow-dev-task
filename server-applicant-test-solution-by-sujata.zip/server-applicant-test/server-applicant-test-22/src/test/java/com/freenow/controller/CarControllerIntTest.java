/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.controller;

import com.freenow.dataaccessobject.CarRepository;
import com.freenow.dataaccessobject.DriverRepository;
import com.freenow.domainobject.CarDO;
import com.freenow.domainobject.ManufacturerDO;
import com.freenow.domainvalue.EngineType;
import com.freenow.service.car.CarService;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.Arrays;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@SpringBootTest
public class CarControllerIntTest {
    @Autowired
    private WebApplicationContext wac;
    private MockMvc mockMvc;
    private CarDO car1 = new CarDO();
    private CarDO car2 = new CarDO();

    @Autowired
    private DriverRepository driverRepository;

    @Autowired
    private CarRepository carRepository;

    @MockBean
    CarService carServiceMock;

    @BeforeAll
    public static void setUpAll() {

    }

    @AfterAll
    public static void tearDownAll() {
    }

    @BeforeEach
    public void pretest() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
    }

    @BeforeEach
    public void setUp() {
        car1.setLicensePlate("B-MM-1985E");
        car1.setManufacturer(new ManufacturerDO("BMW"));
        car1.setEngineType(EngineType.Hybrid);
        car1.setRating(Float.valueOf("5"));
        car2.setLicensePlate("D-MM-1985E");
        car2.setManufacturer(new ManufacturerDO("MERCEDES"));
        car2.setEngineType(EngineType.Electric);
        car2.setRating(Float.valueOf("5"));
        carRepository.save(car1);
        carRepository.save(car2);

        when(carServiceMock.getAll()).thenReturn(Arrays.asList(car1, car2));
    }

    @AfterEach
    public void tearDown() {
        driverRepository.deleteAll();
        carRepository.deleteAll();
    }

    @Test
    public void testGetAllCars() throws Exception {
        mockMvc.perform(get("/v1/?cars/allCars"))
                .andExpect(status().isOk());
    }

}