/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.criteria.car;

import com.freenow.domainobject.CarDO;

import java.util.List;
import java.util.stream.Collectors;

/**
 * License plate criteria
 * @author Sujata
 * @version 1.0
 * @since 23-NOV-19
 * */
public class LicensePlateCarCriteria implements CarCriteria {
    private final String licensePlate;

    public LicensePlateCarCriteria(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    @Override
    public List<CarDO> meetCriteria(List<CarDO> cars) {
        return cars.stream()
                .filter(c-> c.getLicensePlate().equals(this.licensePlate))
                .collect(Collectors.toList());
    }


}
