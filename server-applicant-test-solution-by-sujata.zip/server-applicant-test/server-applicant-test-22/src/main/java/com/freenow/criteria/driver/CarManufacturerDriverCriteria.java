/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.criteria.driver;

import com.freenow.domainobject.DriverDO;
import com.freenow.domainobject.ManufacturerDO;

import java.util.List;
import java.util.stream.Collectors;

public class CarManufacturerDriverCriteria implements DriverCriteria {
    private final ManufacturerDO manufacturer;

    public CarManufacturerDriverCriteria(ManufacturerDO manufacturer) {
        this.manufacturer = manufacturer;
    }

    @Override
    public List<DriverDO> meetCriteria(List<DriverDO> drivers) {
        return drivers.stream()
                .filter(d->(d.getCar() != null && d.getCar().getManufacturer() != null && d.getCar().getManufacturer().equals(manufacturer)))
                .collect(Collectors.toList());
    }
}
