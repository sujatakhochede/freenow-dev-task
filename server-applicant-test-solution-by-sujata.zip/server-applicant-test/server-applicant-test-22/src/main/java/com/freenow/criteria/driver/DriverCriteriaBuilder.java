/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.criteria.driver;

import com.freenow.datatransferobject.SearchDTO;
import com.freenow.domainobject.ManufacturerDO;
import com.freenow.domainvalue.AttributeType;
import com.freenow.domainvalue.CriteriaType;
import com.freenow.domainvalue.OnlineStatus;
import com.freenow.exception.InvalidCriteriaException;
import org.springframework.util.StringUtils;


public class DriverCriteriaBuilder {
    static DriverCriteria rootCriteria = null;

    private DriverCriteriaBuilder(){}

    public static DriverCriteria build(SearchDTO node) throws InvalidCriteriaException {

        if (node == null) {
            return null;
        }

        if (CriteriaType.AND == node.getCriteriaType()) {
            DriverCriteria criteria1 = buildCriteria(node.getAttribute(), node.getValue());
            if (node.getOtherCriteria() != null) {
                DriverCriteria criteria2 = build(node.getOtherCriteria());
                rootCriteria = new AndDriverCriteria(criteria1, criteria2);
            }

        } else if (CriteriaType.OR == node.getCriteriaType()) {
            DriverCriteria criteria1 = buildCriteria(node.getAttribute(), node.getValue());
            if (node.getOtherCriteria() != null) {
                DriverCriteria criteria2 = build(node.getOtherCriteria());
                rootCriteria = new OrDriverCriteria(criteria1, criteria2);
            }

        } else {
            AttributeType attribute = node.getAttribute();
            String value = node.getValue();
            rootCriteria = buildCriteria(attribute, value);
        }

        return rootCriteria;
    }

    private static DriverCriteria buildCriteria(AttributeType attribute, String value) throws InvalidCriteriaException {
        DriverCriteria criteria = null;
        switch (attribute) {
            case RATING:
                criteria = new CarRatingDriverCriteria(getRating(value));
                break;
            case MANUFACTURER:
                criteria = new CarManufacturerDriverCriteria(getMaufacturer(value));
                break;
            case ONLINE_STATUS:
                criteria = new OnlineStatusDriverCriteria(getOnlineStatus(value));
                break;
            case USERNAME:
                criteria = new UserNameDriverCriteria(getUserName(value));
                break;
            default:
                break;
        }
        return criteria;
    }

    private static ManufacturerDO getMaufacturer(String value) {
       return new ManufacturerDO(value);
    }

    private static Float getRating(String value) throws InvalidCriteriaException {
        Float rating;
        try {
            rating = Float.valueOf(value);
        } catch (IllegalArgumentException e) {
            throw new InvalidCriteriaException("Invalid rating");
        }
        return rating;
    }

    private static OnlineStatus getOnlineStatus(String value) throws InvalidCriteriaException {
        OnlineStatus onlineStatus;
        try {
            onlineStatus = OnlineStatus.valueOf(value);
        } catch (IllegalArgumentException e) {
            throw new InvalidCriteriaException("Invalid online status, valid status: OFFLINE/ONLINE");
        }
        return onlineStatus;
    }

    private static String getUserName(String value) throws InvalidCriteriaException {
        if (StringUtils.isEmpty(value)) {
            throw new InvalidCriteriaException("Username can not be empty");
        }
        return value;
    }

}
