/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.criteria.driver;

import com.freenow.domainobject.DriverDO;

import java.util.List;


public class AndDriverCriteria implements DriverCriteria {
    private DriverCriteria criteria;
    private DriverCriteria otherCriteria;

    public AndDriverCriteria(DriverCriteria criteria, DriverCriteria otherCriteria) {
        this.criteria = criteria;
        this.otherCriteria = otherCriteria;
    }

    @Override
    public List<DriverDO> meetCriteria(List<DriverDO> drivers) {
        List<DriverDO> firstCriteriaItems = criteria.meetCriteria(drivers);
        return otherCriteria.meetCriteria(firstCriteriaItems);
    }
}
