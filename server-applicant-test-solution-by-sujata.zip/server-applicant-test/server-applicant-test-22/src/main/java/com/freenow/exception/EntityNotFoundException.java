/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND, reason = "Could not get entity with id.")
public class EntityNotFoundException extends Exception
{
    static final long serialVersionUID = -3387516993334229948L;


    public EntityNotFoundException(String message)
    {
        super(message);
    }

}
