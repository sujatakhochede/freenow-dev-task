/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.criteria.car;

import com.freenow.domainobject.CarDO;
import com.freenow.domainobject.ManufacturerDO;

import java.util.List;
import java.util.stream.Collectors;

public class CarManufacturerCarCriteria implements CarCriteria {

    private final ManufacturerDO manufacturer;

    public CarManufacturerCarCriteria(ManufacturerDO manufacturer) {
        this.manufacturer = manufacturer;
    }

    @Override
    public List<CarDO> meetCriteria(List<CarDO> cars) {
        return cars.stream()
                .filter(c-> c.getManufacturer().equals(manufacturer))
                .collect(Collectors.toList());
    }
}
