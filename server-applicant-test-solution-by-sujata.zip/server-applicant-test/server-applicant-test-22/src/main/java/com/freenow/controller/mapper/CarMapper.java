/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.controller.mapper;

import com.freenow.datatransferobject.CarDTO;
import com.freenow.domainobject.CarDO;
import com.freenow.domainvalue.GeoCoordinate;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Mapper for car data transfer object
 * @author Sujata
 * @since 22-NOV-2019
 * @version 1.0
 * */
public class CarMapper {
    public static CarDO makeCarDO(CarDTO carDTO) {
        return new CarDO(carDTO.getId(), carDTO.getLicensePlate(), (short) carDTO.getSeatCount(), carDTO.isConvertible(), carDTO.getRating(), carDTO.getEngineType(), carDTO.getManufacturer());

    }

    public static CarDTO makeCarDTO(CarDO carDo) {
        CarDTO.CarDTOBuilder carDTOBuilder = CarDTO.newBuilder()
                .setId(carDo.getId())
                .setLicensePlate(carDo.getLicensePlate())
                .setManufacturer(carDo.getManufacturer())
                .setEngineType(carDo.getEngineType())
                .setRating(carDo.getRating())
                .setSeatCount(carDo.getSeatCount())
                .setCoordinate(carDo.getCoordinate())
                .setSelected(carDo.getDriver() != null ? true : false)
                .setConvertible(carDo.getConvertible());
        GeoCoordinate coordinate = carDo.getCoordinate();
        if (coordinate != null) {
            carDTOBuilder.setCoordinate(coordinate);
        }

        return carDTOBuilder.CarDTOBuilder();
    }

    public static List<CarDTO> makeCarDTOList(Collection<CarDO> cars) {
        return cars.stream()
                .map(CarMapper::makeCarDTO)
                .collect(Collectors.toList());
    }
}