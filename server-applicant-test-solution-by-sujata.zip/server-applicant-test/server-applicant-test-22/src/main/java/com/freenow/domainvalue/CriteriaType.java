/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.domainvalue;

public enum CriteriaType {
    AND, OR
}
