/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.service;

import com.freenow.criteria.car.CarCriteria;
import com.freenow.criteria.car.CarEngineCarCriteria;
import com.freenow.criteria.driver.CarManufacturerDriverCriteria;
import com.freenow.criteria.driver.CarRatingDriverCriteria;
import com.freenow.criteria.driver.DriverCriteria;
import com.freenow.criteria.driver.OnlineStatusDriverCriteria;
import com.freenow.dataaccessobject.CarRepository;
import com.freenow.dataaccessobject.DriverRepository;
import com.freenow.domainobject.CarDO;
import com.freenow.domainobject.DriverDO;
import com.freenow.domainobject.ManufacturerDO;
import com.freenow.domainvalue.EngineType;
import com.freenow.domainvalue.OnlineStatus;
import com.freenow.exception.CarAlreadyInUseException;
import com.freenow.exception.ConstraintsViolationException;
import com.freenow.exception.EntityNotFoundException;
import com.freenow.service.car.CarService;
import com.freenow.service.driver.DriverService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DriverServiceTest {
    private static org.slf4j.Logger LOG = LoggerFactory.getLogger(DriverServiceTest.class);

    @Autowired
    private CarService carService;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private DriverService driverService;

    @Autowired
    private DriverRepository driverRepository;

    private CarDO car1 = new CarDO();
    private CarDO car2 = new CarDO();
    private DriverDO driver1 = new DriverDO("user1", "passwordX");
    private DriverDO driver2 = new DriverDO("user2", "password2");
    ManufacturerDO manufacturerMaruti =  new ManufacturerDO("MARUTI");


    @Before
    public void SetUp() {
        car1.setLicensePlate("LicensePlate1");
        car1.setManufacturer(new ManufacturerDO("AUDI"));
        car1.setEngineType(EngineType.Hybrid);
        car1.setRating(Float.valueOf("4"));
        car2.setLicensePlate("LicensePlate2");
        car2.setManufacturer(manufacturerMaruti);
        car2.setEngineType(EngineType.Electric);
        car2.setRating(Float.valueOf("5"));
        carRepository.save(car1);
        carRepository.save(car2);

        driver1.setOnlineStatus(OnlineStatus.ONLINE);
        driver1.setCar(car1);
        driverRepository.save(driver1);

        driver2.setOnlineStatus(OnlineStatus.ONLINE);
        driver2.setCar(car2);
        driverRepository.save(driver2);
    }

    @After
    public void tearDown() {
        driverRepository.deleteAll();
        carRepository.deleteAll();
    }

    @Test
    public void testAssignCarToDriver() throws EntityNotFoundException, ConstraintsViolationException, CarAlreadyInUseException {
        DriverDO driver =  driverService.assignCarToDriver(car1.getId(), driver1.getId());
        assertEquals(driver.getCar().getId(), car1.getId());
    }

    @Test(expected = CarAlreadyInUseException.class)
    public void testAssignAlreadyAssignedCarToDriver() throws EntityNotFoundException, ConstraintsViolationException, CarAlreadyInUseException {
        DriverDO driver =  driverService.assignCarToDriver(car1.getId(), driver1.getId());
        //trying t assign a car which already in use to the driver
        driverService.assignCarToDriver(car1.getId(), driver2.getId());
    }

    @Test
    public void testSearchDriversByCarRating(){
        DriverCriteria driverCriteria = new CarRatingDriverCriteria(Float.valueOf("5"));
        List<DriverDO> drivers =  driverService.findByCriteria(driverCriteria);
        assertEquals(Float.valueOf("5"), drivers.get(0).getCar().getRating());
    }

    @Test
    public void testSearchDriversByCarManufacturer(){
       DriverCriteria driverCriteria = new CarManufacturerDriverCriteria(manufacturerMaruti);
        List<DriverDO> drivers =  driverService.findByCriteria(driverCriteria);
        assertEquals(manufacturerMaruti, drivers.get(0).getCar().getManufacturer());
    }

    @Test
    public void testSearchDriversByStatus(){
        DriverCriteria driverCriteria = new OnlineStatusDriverCriteria(OnlineStatus.ONLINE);
        List<DriverDO> drivers =  driverService.findByCriteria(driverCriteria);
        assertEquals(OnlineStatus.ONLINE, drivers.get(0).getOnlineStatus());
    }

    @Test
    public void testSearchDriversByEngineType() {
        CarCriteria engineCriteria = new CarEngineCarCriteria(EngineType.Hybrid);
        List<CarDO> filteredCars = carService.findByCriteria(engineCriteria);
        assertEquals(car1.getId(), filteredCars.get(0).getId());
    }
}
