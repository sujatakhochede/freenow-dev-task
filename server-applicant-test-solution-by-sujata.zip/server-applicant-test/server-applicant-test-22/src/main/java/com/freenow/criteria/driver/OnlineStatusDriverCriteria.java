/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.criteria.driver;

import com.freenow.domainobject.DriverDO;
import com.freenow.domainvalue.OnlineStatus;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Online Status Driver Criteria
 * @author Sujata
 * @version 1.0
 * @since 23-NOV-19
 * */
public class OnlineStatusDriverCriteria implements DriverCriteria {
    private final OnlineStatus onlineStatus;

    public OnlineStatusDriverCriteria(OnlineStatus onlineStatus) {
        this.onlineStatus = onlineStatus;
    }

    @Override
    public List<DriverDO> meetCriteria(List<DriverDO> drivers) {
        return drivers.stream()
                .filter(d->d.getOnlineStatus().equals(this.onlineStatus))
                .collect(Collectors.toList());
    }
}
