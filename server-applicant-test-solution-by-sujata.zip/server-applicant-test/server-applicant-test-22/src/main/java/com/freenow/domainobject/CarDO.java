/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.domainobject;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.freenow.domainvalue.EngineType;
import com.freenow.domainvalue.GeoCoordinate;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import java.time.ZonedDateTime;
import java.util.Objects;

@Entity
@Table(name = "car"
        //uniqueConstraints = @UniqueConstraint(name = "_licensePlate", columnNames = {"licensePlate"})
)
public class CarDO {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    @NotNull(message = "License plate cannot be empty.")
    private String licensePlate;

    @Column
    private Short seatCount;

    @Column
    private Boolean convertible;

    @Column
    private Float rating;

    @Column
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime dateCreated = ZonedDateTime.now();

    @Enumerated(EnumType.STRING)
    @Column
    private EngineType engineType;

    @Embedded
    private GeoCoordinate coordinate;

    @Column
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    private ZonedDateTime dateCoordinateUpdated = ZonedDateTime.now();


    private ManufacturerDO manufacturer;

    @JsonIgnore
    @OneToOne(mappedBy = "car", fetch = FetchType.LAZY, cascade = CascadeType.DETACH)
    private DriverDO driver;

    public CarDO() {
    }

    public CarDO(Long id, String licensePlate, Short seatCount, Boolean convertible, Float rating,  EngineType engineType, ManufacturerDO manufacturer) {
        this.id = id;
        this.licensePlate = licensePlate;
        this.seatCount = seatCount;
        this.convertible = convertible;
        this.rating = rating;
        this.engineType = engineType;
        this.manufacturer = manufacturer;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ZonedDateTime getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(ZonedDateTime dateCreated) {
        this.dateCreated = dateCreated;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public Short getSeatCount() {
        return seatCount;
    }

    public void setSeatCount(Short seatCount) {
        this.seatCount = seatCount;
    }

    public Boolean getConvertible() {
        return convertible;
    }

    public void setConvertible(Boolean convertible) {
        this.convertible = convertible;
    }

    public Float getRating() {
        return rating;
    }

    public void setRating(Float rating) {
        this.rating = rating;
    }

    public GeoCoordinate getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(GeoCoordinate coordinate) {
        this.coordinate = coordinate;
        this.dateCoordinateUpdated = ZonedDateTime.now();
    }

    public ZonedDateTime getDateCoordinateUpdated() {
        return dateCoordinateUpdated;
    }

    public void setDateCoordinateUpdated(ZonedDateTime dateCoordinateUpdated) {
        this.dateCoordinateUpdated = dateCoordinateUpdated;
    }

    public EngineType getEngineType() {
        return engineType;
    }

    public void setEngineType(EngineType engineType) {
        this.engineType = engineType;
    }

    public ManufacturerDO getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(ManufacturerDO manufacturer) {
        this.manufacturer = manufacturer;
    }

    public DriverDO getDriver() {
        return driver;
    }

    public void setDriver(DriverDO driver) {
        this.driver = driver;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CarDO)) return false;
        CarDO carDO = (CarDO) o;
        return Objects.equals(getId(), carDO.getId()) &&
                Objects.equals(getDateCreated(), carDO.getDateCreated()) &&
                Objects.equals(getLicensePlate(), carDO.getLicensePlate()) &&
                Objects.equals(getSeatCount(), carDO.getSeatCount()) &&
                Objects.equals(getConvertible(), carDO.getConvertible()) &&
                Objects.equals(getRating(), carDO.getRating()) &&
                Objects.equals(getCoordinate(), carDO.getCoordinate()) &&
                Objects.equals(getDateCoordinateUpdated(), carDO.getDateCoordinateUpdated()) &&
                getEngineType() == carDO.getEngineType() &&
                Objects.equals(getManufacturer(), carDO.getManufacturer()) &&
                Objects.equals(getDriver(), carDO.getDriver());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getId(), getDateCreated(), getLicensePlate(), getSeatCount(), getConvertible(), getRating(), getCoordinate(), getDateCoordinateUpdated(), getEngineType(), getManufacturer(), getDriver());
    }

    @Override
    public String toString() {
        return "CarDO{" +
                "id=" + id +
                ", licensePlate='" + licensePlate + '\'' +
                ", seatCount=" + seatCount +
                ", convertible=" + convertible +
                ", rating=" + rating +
                ", dateCreated=" + dateCreated +
                ", engineType=" + engineType +
                ", coordinate=" + coordinate +
                ", dateCoordinateUpdated=" + dateCoordinateUpdated +
                ", manufacturer=" + manufacturer +
                ", driver=" + driver +
                '}';
    }
}
