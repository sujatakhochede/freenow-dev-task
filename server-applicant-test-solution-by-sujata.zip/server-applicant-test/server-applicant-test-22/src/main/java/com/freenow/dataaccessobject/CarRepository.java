/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.dataaccessobject;

import com.freenow.domainobject.CarDO;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Repository for car CRUD operations
 * @author Sujata
 * @since 22-NOV-2019
 * @version 1.0
 * */
public interface CarRepository extends CrudRepository<CarDO, Long>
{

    @Query(value = "SELECT * from Car car WHERE car.id=:id", nativeQuery = true)
    CarDO findCarById(@Param("id") Long id);


    CarDO findByLicensePlate(String licensePlate);

    @Query(value = "SELECT * from Car car WHERE car.id NOT IN (select driver.Car_ID from Driver driver)", nativeQuery = true)
    List<CarDO> findByDriverIsNull();

    //    CarDO findOne(Long carId);
}
