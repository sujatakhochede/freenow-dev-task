/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.criteria.car;

import com.freenow.domainobject.CarDO;

import java.util.List;

public class AndCarCriteria implements CarCriteria
{

    private CarCriteria criteria;
    private CarCriteria otherCriteria;


    public AndCarCriteria(CarCriteria criteria, CarCriteria otherCriteria)
    {
        this.criteria = criteria;
        this.otherCriteria = otherCriteria;
    }


    @Override
    public List<CarDO> meetCriteria(List<CarDO> cars)
    {
        List<CarDO> firstCriteriaItems = criteria.meetCriteria(cars);
        return otherCriteria.meetCriteria(firstCriteriaItems);

    }

}
