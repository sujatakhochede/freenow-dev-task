/**
 * CREATE Script for init of DB
 */

-- Create 4 cars

--insert into car (id, licensePlate, seatCount, convertible, rating, engineType, manufacturer) values (1, "lp1", 4, true, 5 , 'Gas', "HONDA");

--insert into car (id, licensePlate, seatCount, convertible, rating, engineType, manufacturer) values (2, "LP-2", 4, true, 5 , 'Electric', "OOODY");

--insert into car (id, licensePlate, seatCount, convertible, rating, engineType, manufacturer) values (3, "LP-3", 4, true, 5 , 'Petrol', "BENZ");

--insert into car (id, licensePlate, seatCount, convertible, rating, engineType, manufacturer) values (4, "LP-4", 4, true, 5 , 'Diesel', "MARUTI");

-- Create 4 OFFLINE drivers

insert into driver (id, date_created, deleted, online_status, password, username) values (1, now(), false, 'OFFLINE','password01', 'driver01');

insert into driver (id, date_created, deleted, online_status, password, username) values (2, now(), false, 'OFFLINE','password02', 'driver02');

insert into driver (id, date_created, deleted, online_status, password, username) values (3, now(), false, 'OFFLINE','password03', 'driver03');

insert into driver (id, date_created, deleted, online_status, password, username) values (4, now(), false, 'OFFLINE','password04', 'driver04');


-- Create 4 ONLINE drivers

insert into driver (id, date_created, deleted, online_status, password, username) values (5, now(), false, 'ONLINE','password05', 'driver05');

insert into driver (id, date_created, deleted, online_status, password, username) values (6, now(), false, 'ONLINE','password06', 'driver06');

insert into driver (id, date_created, deleted, online_status, password, username) values (7, now(), false, 'ONLINE','password07', 'driver07');

insert into driver (id, date_created, deleted, online_status, password, username) values (8, now(), false, 'ONLINE','password08', 'driver08');

-- Create 1 OFFLINE driver with coordinate(longitude=9.5&latitude=55.954)

--insert into driver (id, coordinate, date_coordinate_updated, date_created, deleted, online_status, password, username)
--values
 --(9,
-- 'aced0005737200226f72672e737072696e676672616d65776f726b2e646174612e67656f2e506f696e7431b9e90ef11a4006020002440001784400017978704023000000000000404bfa1cac083127', now(), now(), false, 'OFFLINE',
--'password09', 'driver09');

-- Create 1 ONLINE driver with coordinate(longitude=9.5&latitude=55.954)

--insert into driver (id, coordinate, date_coordinate_updated, date_created, deleted, online_status, password, username)
--values
-- (10,
 --'aced0005737200226f72672e737072696e676672616d65776f726b2e646174612e67656f2e506f696e7431b9e90ef11a4006020002440001784400017978704023000000000000404bfa1cac083127', now(), now(), false, 'ONLINE',
--'password10', 'driver10');