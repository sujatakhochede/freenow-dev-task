/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.service;

import com.freenow.criteria.car.CarCriteria;
import com.freenow.criteria.car.CarEngineCarCriteria;
import com.freenow.criteria.driver.CarRatingDriverCriteria;
import com.freenow.criteria.driver.DriverCriteria;
import com.freenow.dataaccessobject.CarRepository;
import com.freenow.dataaccessobject.DriverRepository;
import com.freenow.domainobject.CarDO;
import com.freenow.domainobject.DriverDO;
import com.freenow.domainobject.ManufacturerDO;
import com.freenow.domainvalue.EngineType;
import com.freenow.domainvalue.OnlineStatus;
import com.freenow.exception.CarAlreadyInUseException;
import com.freenow.exception.ConstraintsViolationException;
import com.freenow.exception.EntityNotFoundException;
import com.freenow.service.car.CarService;
import com.freenow.service.driver.DriverService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CarServiceTest {
    private static org.slf4j.Logger LOG = LoggerFactory.getLogger(CarServiceTest.class);
    @Autowired
    private CarService carService;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private DriverService driverService;

    @Autowired
    private DriverRepository driverRepository;

    private CarDO car1 = new CarDO();
    private CarDO car2 = new CarDO();

    @Before
    public void setUp() {
        car1.setLicensePlate("B-MM-1985E");
        car1.setManufacturer(new ManufacturerDO("BMW"));
        car1.setEngineType(EngineType.Hybrid);
        car1.setRating(Float.valueOf("5"));
        car2.setLicensePlate("D-MM-1985E");
        car2.setManufacturer(new ManufacturerDO("MERCEDES"));
        car2.setEngineType(EngineType.Electric);
        car2.setRating(Float.valueOf("5"));
        carRepository.save(car1);
        carRepository.save(car2);
    }

    @After
    public void tearDown() {
        driverRepository.deleteAll();
        carRepository.deleteAll();
    }

    @Test
    public void testGetAllCars() {
        List<CarDO> cars = (List<CarDO>) carRepository.findAll();
        LOG.info("Cars number : {}", cars.size());
        assertNotNull(cars);
        assertEquals(2, cars.size());
    }


    @Test
    public void testGetCarByLicensePlate() {
        CarDO car = carRepository.findByLicensePlate("B-MM-1985E");
        LOG.info("car : {}", car.toString());
        System.out.println("car.toString() = " + car.toString());
        assertNotNull(car);
        assertEquals("BMW", car.getManufacturer().getManufacturer());
    }



    @Test
    public void testGetAvailableCars() {
        List<CarDO> cars = carService.getAvailableCars();
        LOG.info("Cars number : {}", cars.size());
        assertNotNull(cars);
        assertEquals(2, cars.size());
    }

    @Test
    public void testCreateCar() throws ConstraintsViolationException {
        CarDO transientCar = new CarDO();
        transientCar.setLicensePlate("E-MM-1985E");
        transientCar.setEngineType(EngineType.Hybrid);
        transientCar.setManufacturer(new ManufacturerDO("HONDA"));
        transientCar.setSeatCount(Short.valueOf("5"));
        CarDO persistedCar = carService.create(transientCar);
        assertNotNull(persistedCar);
//        assertEquals(ZonedDateTime.now().getMinute(), persistedCar.getDateCreated().getMinute());
        assertNotNull(persistedCar.getId());
    }


    @Test(expected = EntityNotFoundException.class)
    public void testGetNotExistCar() throws EntityNotFoundException {
        carService.get(Long.valueOf("100"));
    }



    @Test
    public void testAssignCar() throws EntityNotFoundException, CarAlreadyInUseException, ConstraintsViolationException {
        DriverDO driverDO = new DriverDO("user1", "password1");
        driverDO.setOnlineStatus(OnlineStatus.ONLINE);
        DriverDO driver = driverRepository.save(driverDO);

        CarDO car = carRepository.findByLicensePlate("B-MM-1985E");
        DriverDO newDriver = driverService.assignCarToDriver(car.getId(), driver.getId());
        assertNotNull(newDriver.getCar());
        assertEquals(car.getLicensePlate(), newDriver.getCar().getLicensePlate());
    }

    @Test
    public void testSearchCars() {
        CarCriteria engineCriteria = new CarEngineCarCriteria(EngineType.Hybrid);
        List<CarDO> filteredCars = carService.findByCriteria(engineCriteria);
        assertEquals(car1.getId(), filteredCars.get(0).getId());
    }

    @Test
    public void testSearchDriversByCarRating() throws EntityNotFoundException, CarAlreadyInUseException, ConstraintsViolationException {
        DriverDO driver1 = new DriverDO("user2", "password2");
        DriverDO driver2 = new DriverDO("username3", "password3");
        driver1.setOnlineStatus(OnlineStatus.ONLINE);
        DriverDO persistedDriver1 = driverRepository.save(driver1);
        CarDO carX = new CarDO();
        carX.setLicensePlate("LicensePlate2");
        carX.setManufacturer(new ManufacturerDO("TOYOTA"));
        carX.setEngineType(EngineType.Hybrid);
        carX.setRating(Float.valueOf("5"));
        CarDO persistedCarX = carRepository.save(carX);
//        driver1.setCar(carX);
        driverService.assignCarToDriver(persistedCarX.getId(),persistedDriver1.getId());

        driver2.setOnlineStatus(OnlineStatus.ONLINE);
        DriverDO persistedDriver2 = driverRepository.save(driver2);
        CarDO carY = new CarDO();
        carY.setLicensePlate("LicensePlate3");
        carY.setManufacturer(new ManufacturerDO("MERCEDES"));
        carY.setEngineType(EngineType.Electric);
        carY.setRating(Float.valueOf("5"));
        CarDO persistedCarY = carRepository.save(carY);
        driverService.assignCarToDriver(persistedCarY.getId(),persistedDriver2.getId());
//        driver2.setCar(carY);


        DriverCriteria driverCriteria = new CarRatingDriverCriteria(Float.valueOf("5"));
        List<DriverDO> drivers = driverService.findByCriteria(driverCriteria);
        assertEquals("LicensePlate2", drivers.get(0).getCar().getLicensePlate());

    }

}
