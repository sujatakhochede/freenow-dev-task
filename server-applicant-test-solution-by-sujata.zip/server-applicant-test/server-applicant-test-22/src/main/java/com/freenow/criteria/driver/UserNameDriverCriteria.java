/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.criteria.driver;

import com.freenow.domainobject.DriverDO;

import java.util.List;
import java.util.stream.Collectors;

/**
 * User name Driver Criteria
 * @author Sujata
 * @version 1.0
 * @since 23-NOV-19
 * */
public class UserNameDriverCriteria implements DriverCriteria {
    private final String userName;

    public UserNameDriverCriteria(String userName) {
        this.userName = userName;
    }

    @Override
    public List<DriverDO> meetCriteria(List<DriverDO> drivers) {
        return drivers.stream()
                .filter(d->d.getUsername().equals(this.userName))
                .collect(Collectors.toList());
    }
}
