/*
 *   Copyright (c) 2019 The Free Now Dev Task.
 *   All Rights Reserved.
 *
 *   The information specified here is confidential and remains property of the Free Now Recruiting.
 */

package com.freenow.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "The car has already been assigned.")
public class CarAlreadyAssignedException extends Exception
{

    /**
     * 
     */
    private static final long serialVersionUID = -6307562822969568540L;


    public CarAlreadyAssignedException(String exceptionMessage)
    {
        super(exceptionMessage);
    }

}
